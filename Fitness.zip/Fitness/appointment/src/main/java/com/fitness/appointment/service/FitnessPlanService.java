package com.fitness.appointment.service;

import com.fitness.appointment.entity.FitnessPlan;

import java.util.List;

public interface FitnessPlanService {
    List<FitnessPlan> getFitnessPlanData();

    FitnessPlan getFitnessPlanById(Integer planId);

}
