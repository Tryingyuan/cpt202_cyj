package com.fitness.appointment.service;

import com.fitness.appointment.entity.Member;

import java.util.List;

// MemberService.java
public interface MemberService {
    Member getMemberById(Integer memberId);

    void updateMemberWithFitnessPlan(String planLevel, String planDate, Integer memberId);
}