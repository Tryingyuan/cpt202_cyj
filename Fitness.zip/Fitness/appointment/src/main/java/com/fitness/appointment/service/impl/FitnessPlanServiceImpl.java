package com.fitness.appointment.service.impl;

import com.fitness.appointment.dao.FitnessPlanRepository;
import com.fitness.appointment.entity.FitnessPlan;
import com.fitness.appointment.service.FitnessPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FitnessPlanServiceImpl implements FitnessPlanService {

    private final FitnessPlanRepository fitnessPlanRepository;

    @Autowired
    public FitnessPlanServiceImpl(FitnessPlanRepository fitnessPlanRepository) {
        this.fitnessPlanRepository = fitnessPlanRepository;
    }

    @Override
    public List<FitnessPlan> getFitnessPlanData() {
        return fitnessPlanRepository.findAll();
    }

    @Override
    public FitnessPlan getFitnessPlanById(Integer planId) {
        return fitnessPlanRepository.findById(planId).orElse(null);
    }
}
