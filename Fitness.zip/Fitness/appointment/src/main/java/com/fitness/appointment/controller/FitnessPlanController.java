package com.fitness.appointment.controller;

import com.fitness.appointment.entity.FitnessPlan;
import com.fitness.appointment.entity.Result;
import com.fitness.appointment.service.FitnessPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class FitnessPlanController {
    @Autowired
    private FitnessPlanService fitnessPlanService;

    @GetMapping("/fitnessPlan")
    public String getFitnessPlan(Model model){
        List<FitnessPlan> fitnessPlans = fitnessPlanService.getFitnessPlanData();
        model.addAttribute("fitnessPlans", fitnessPlans);
        System.out.print(fitnessPlans);

        return "FitnessPlan";
    }


}


