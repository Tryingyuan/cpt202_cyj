package com.fitness.appointment.controller;
import com.fitness.appointment.entity.FitnessPlan;
import com.fitness.appointment.entity.Member;
import com.fitness.appointment.service.FitnessPlanService;
import com.fitness.appointment.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.Map;

/**
 * Purchase a fitness plan before membership appointment
 */
@RestController
@RequestMapping("/members")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @Autowired
    private FitnessPlanService fitnessPlanService;

    @PostMapping("/buyPlan")
    public ResponseEntity<String> buyFitnessPlan(@RequestBody Map<String, Integer> requestBody) {
//        Integer id = requestBody.get("id");//null
        Integer planId = requestBody.get("planId");
        int id = 1;

        if ( id == 0 || planId == null ) {
            return ResponseEntity.badRequest().body("Invalid memberId or planId");
        }

        // 从数据库中获取健身计划的计划级别和计划日期
        FitnessPlan fitnessPlan = fitnessPlanService.getFitnessPlanById(planId);
        if (fitnessPlan == null) {
            return ResponseEntity.badRequest().body("Invalid planId");
        }

        String planLevel = fitnessPlan.getPlanLevel();
        String planDate = fitnessPlan.getPlanDate();

        // 更新会员的计划级别和计划日期
        memberService.updateMemberWithFitnessPlan(planLevel, planDate, id);

        return ResponseEntity.ok("Member's fitness plan updated successfully!");
    }

}