package com.fitness.appointment.service.impl;
import com.fitness.appointment.dao.MemberRepository;
import com.fitness.appointment.entity.Member;
import com.fitness.appointment.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;

    @Autowired
    public MemberServiceImpl(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    @Override
    public Member getMemberById(Integer memberId) {
        return memberRepository.findById(memberId).orElse(null);
    }

    @Override
    public void updateMemberWithFitnessPlan(String planLevel, String planDate, Integer memberId) {
        Member member = memberRepository.findById(memberId).orElse(null);
        if (member != null) {
            member.setPlanLevel(planLevel);
            member.setPlanDate(planDate);
            memberRepository.save(member);
        }
    }
}