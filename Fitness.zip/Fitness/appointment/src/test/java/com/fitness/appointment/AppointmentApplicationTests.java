package com.fitness.appointment;

import com.fitness.appointment.entity.Member;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentApplicationTests {

//	@Resource
//	Member member;

	@Test
	void contextLoads() {
//		System.out.println(member);
	}

}
